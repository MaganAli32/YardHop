import { useState, useEffect } from "react";
import { colors, fonts } from "../../lib/tokens";

interface SafariMockupProps {
  visible: boolean;
}

/**
 * macOS Safari-style browser chrome wrapping
 * the YardFront app interface.
 * Staged reveal: photo identified → item details → price + range bar
 */
export function SafariMockup({ visible }: SafariMockupProps) {
  const [step, setStep] = useState(0);

  useEffect(() => {
    if (!visible) return;
    const timers = [
      setTimeout(() => setStep(1), 1200),
      setTimeout(() => setStep(2), 2200),
      setTimeout(() => setStep(3), 3000),
    ];
    return () => timers.forEach(clearTimeout);
  }, [visible]);

  return (
    <div
      style={{
        background: colors.chalk,
        borderRadius: 14,
        border: `1px solid ${colors.stone}30`,
        boxShadow: `0 60px 120px -20px ${colors.forest}25, 0 24px 48px -12px ${colors.forest}15, 0 0 0 1px ${colors.stone}10`,
        overflow: "hidden",
        opacity: visible ? 1 : 0,
        transform: visible
          ? "translateY(0) scale(1)"
          : "translateY(40px) scale(0.97)",
        transition: "all 1.2s cubic-bezier(0.16,1,0.3,1) 0.5s",
      }}
    >
      {/* ── Safari Chrome ── */}
      <div
        style={{
          height: 44,
          background: colors.parchment,
          borderBottom: `1px solid ${colors.stone}20`,
          display: "flex",
          alignItems: "center",
          padding: "0 16px",
          position: "relative",
        }}
      >
        <div style={{ display: "flex", gap: 7 }}>
          <div style={{ width: 11, height: 11, borderRadius: "50%", background: "#E25D50" }} />
          <div style={{ width: 11, height: 11, borderRadius: "50%", background: "#E8A33A" }} />
          <div style={{ width: 11, height: 11, borderRadius: "50%", background: "#51B958" }} />
        </div>
        <div
          style={{
            position: "absolute",
            left: "50%",
            transform: "translateX(-50%)",
            background: colors.chalk,
            padding: "4px 28px",
            borderRadius: 6,
            fontFamily: fonts.sans,
            fontSize: 11,
            color: colors.stone,
            border: `1px solid ${colors.stone}18`,
            display: "flex",
            alignItems: "center",
            gap: 6,
          }}
        >
          <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={{ opacity: 0.45 }} aria-hidden>
            <rect x="5" y="11" width="14" height="10" rx="2" />
            <path d="M8 11V7a4 4 0 018 0v4" />
          </svg>{" "}
          app.yardfront.com
        </div>
      </div>

      {/* ── App Content ── */}
      <div style={{ padding: 28, display: "flex", gap: 28, minHeight: 370 }}>
        {/* Upload zone */}
        <div
          style={{
            flex: 1,
            background: `${colors.stone}0A`,
            borderRadius: 10,
            border: `1px dashed ${colors.stone}30`,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            position: "relative",
            overflow: "hidden",
          }}
        >
          <div
            style={{
              position: "absolute",
              inset: 0,
              backgroundImage: `radial-gradient(${colors.stone}25 1px, transparent 1px)`,
              backgroundSize: "14px 14px",
              opacity: 0.4,
            }}
          />

          {/* Photo stack */}
          <div style={{ position: "relative", width: 120, height: 150 }}>
            <div
              style={{
                width: 120,
                height: 150,
                border: `1.5px solid ${colors.stone}35`,
                background: colors.parchment,
                borderRadius: 8,
                transform: "rotate(-5deg)",
                position: "absolute",
                boxShadow: `0 8px 20px ${colors.forest}12`,
                transition: "all 0.6s ease",
                opacity: step >= 1 ? 1 : 0.4,
              }}
            />
            <div
              style={{
                width: 120,
                height: 150,
                border: `1.5px solid ${step >= 1 ? colors.terra : colors.stone}50`,
                background: colors.chalk,
                borderRadius: 8,
                transform: step >= 1 ? "rotate(2deg) scale(1.02)" : "rotate(2deg)",
                position: "absolute",
                boxShadow:
                  step >= 1
                    ? `0 16px 40px ${colors.forest}20, 0 0 0 2px ${colors.terra}20`
                    : `0 8px 20px ${colors.forest}12`,
                transition: "all 0.8s cubic-bezier(0.16,1,0.3,1)",
              }}
            >
              {step >= 1 && (
                <div
                  className="pop-in"
                  style={{
                    position: "absolute",
                    top: 8,
                    right: 8,
                    width: 18,
                    height: 18,
                    borderRadius: "50%",
                    background: "#51B958",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    fontSize: 10,
                    color: "#fff",
                  }}
                >
                  ✓
                </div>
              )}
            </div>
          </div>

          <div
            style={{
              position: "absolute",
              bottom: 14,
              left: 14,
              fontFamily: fonts.mono,
              fontSize: 10,
              color: colors.bark,
              background: colors.chalk,
              padding: "5px 10px",
              borderRadius: 4,
              opacity: step >= 1 ? 1 : 0.5,
              transition: "opacity 0.4s",
            }}
          >
            {step >= 1 ? "✓ identified" : "awaiting scan..."}
          </div>
        </div>

        {/* Results panel */}
        <div style={{ flex: 1.2, display: "flex", flexDirection: "column" }}>
          {/* Item info */}
          <div
            style={{
              opacity: step >= 2 ? 1 : 0.2,
              transform: step >= 2 ? "translateY(0)" : "translateY(8px)",
              transition: "all 0.7s cubic-bezier(0.16,1,0.3,1)",
            }}
          >
            <div
              style={{
                fontFamily: fonts.sans,
                fontSize: 10,
                color: colors.terra,
                textTransform: "uppercase",
                letterSpacing: "0.1em",
                marginBottom: 10,
              }}
            >
              {step >= 2 ? "Analysis Complete" : "Analyzing..."}
            </div>
            <div
              style={{
                fontFamily: fonts.serif,
                fontSize: 28,
                color: colors.forest,
                lineHeight: 1.15,
                marginBottom: 6,
              }}
            >
              Mid-Century Teak Credenza
            </div>
            <div style={{ fontFamily: fonts.sans, fontSize: 12, color: colors.stone }}>
              Maker: Likely Danish, c. 1960s
            </div>
          </div>

          <div
            style={{
              height: 1,
              background: `${colors.stone}18`,
              margin: "20px 0",
              opacity: step >= 2 ? 1 : 0.2,
              transition: "opacity 0.5s",
            }}
          />

          {/* Price */}
          <div
            style={{
              opacity: step >= 3 ? 1 : 0.15,
              transform: step >= 3 ? "translateY(0)" : "translateY(8px)",
              transition: "all 0.7s cubic-bezier(0.16,1,0.3,1) 0.1s",
            }}
          >
            <div
              style={{
                fontFamily: fonts.sans,
                fontSize: 10,
                color: colors.stone,
                textTransform: "uppercase",
                letterSpacing: "0.1em",
                marginBottom: 8,
              }}
            >
              Estimated Market Value
            </div>
            <div
              style={{
                fontFamily: fonts.sans,
                fontSize: 38,
                fontWeight: 300,
                color: colors.forest,
                letterSpacing: "-0.02em",
                marginBottom: 10,
              }}
            >
              $1,250{" "}
              <span style={{ fontSize: 16, color: colors.stone, fontWeight: 400 }}>
                — $1,600
              </span>
            </div>
            {/* Range bar */}
            <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
              <div
                style={{
                  height: 4,
                  borderRadius: 2,
                  flex: 1,
                  background: `${colors.forest}0C`,
                  overflow: "hidden",
                }}
              >
                <div
                  style={{
                    height: "100%",
                    borderRadius: 2,
                    background: colors.terra,
                    width: step >= 3 ? "72%" : "0%",
                    transition: "width 1.2s cubic-bezier(0.16,1,0.3,1) 0.2s",
                  }}
                />
              </div>
              <span
                style={{
                  fontFamily: fonts.sans,
                  fontSize: 10,
                  color: colors.forest,
                  fontWeight: 600,
                }}
              >
                High Liquidity
              </span>
            </div>
          </div>

          {/* Buttons */}
          <div
            style={{
              display: "flex",
              gap: 10,
              marginTop: "auto",
              paddingTop: 28,
              opacity: step >= 3 ? 1 : 0.15,
              transition: "opacity 0.6s 0.3s",
            }}
          >
            <div
              style={{
                flex: 1,
                padding: "12px",
                borderRadius: 6,
                background: colors.parchment,
                border: `1px solid ${colors.stone}18`,
                fontFamily: fonts.sans,
                fontSize: 11,
                color: colors.forest,
                fontWeight: 600,
                textAlign: "center",
                cursor: "pointer",
              }}
            >
              View Comps (14)
            </div>
            <div
              style={{
                flex: 1,
                padding: "12px",
                borderRadius: 6,
                background: colors.forest,
                color: colors.chalk,
                fontFamily: fonts.sans,
                fontSize: 11,
                fontWeight: 600,
                textAlign: "center",
                cursor: "pointer",
                boxShadow: `0 4px 12px ${colors.forest}20`,
              }}
            >
              Export Dossier
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
