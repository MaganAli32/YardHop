import { Grid, Col } from "../ui/Grid";
import { colors, fonts } from "../../lib/tokens";
import { useReveal } from "../../lib/hooks";

const STATS = [
  { big: "2.4s", sub: "Average time from photo to valuation" },
  { big: "±8%", sub: "Median deviation from actual sale price" },
  { big: "∞", sub: "Categories — if it sells secondhand, we price it" },
];

export function Numbers() {
  const [ref, vis] = useReveal(0.2);

  return (
    <section ref={ref} style={{ padding: "100px 0", background: colors.forest }}>
      <Grid>
        {STATS.map((m, i) => (
          <Col
            key={m.big}
            span={4}
            style={{
              padding: "40px 0",
              textAlign: "center",
              borderRight: i < 2 ? `1px solid ${colors.parchment}10` : "none",
              opacity: vis ? 1 : 0,
              transform: vis ? "translateY(0)" : "translateY(14px)",
              transition: `all 0.7s cubic-bezier(0.16,1,0.3,1) ${i * 0.15}s`,
            }}
          >
            <div
              style={{
                fontFamily: fonts.serif,
                fontSize: 60,
                fontWeight: 300,
                color: colors.terra,
                letterSpacing: "-0.04em",
                lineHeight: 1,
              }}
            >
              {m.big}
            </div>
            <div
              style={{
                fontFamily: fonts.sans,
                fontSize: 13,
                color: `${colors.parchment}55`,
                lineHeight: 1.6,
                marginTop: 14,
                fontWeight: 400,
                maxWidth: 200,
                margin: "14px auto 0",
              }}
            >
              {m.sub}
            </div>
          </Col>
        ))}
      </Grid>
    </section>
  );
}
