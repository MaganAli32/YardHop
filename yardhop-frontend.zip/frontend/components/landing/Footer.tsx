import { Link } from "react-router-dom";
import { Grid, Col } from "../ui/Grid";
import { colors, fonts } from "../../lib/tokens";

export function Footer() {
  return (
    <footer style={{ padding: "32px 0", background: colors.forest }}>
      <Grid style={{ alignItems: "center" }}>
        <Col span={2}>
          <Link
            to="/"
            style={{
              fontFamily: fonts.serif,
              fontSize: 18,
              fontWeight: 500,
              color: `${colors.parchment}40`,
              textDecoration: "none",
            }}
          >
            yf.
          </Link>
        </Col>
        <Col
          span={6}
          style={{
            display: "flex",
            justifyContent: "center",
            gap: 28,
            flexWrap: "wrap",
          }}
        >
          <Link
            to="/privacy-policy"
            style={{
              fontFamily: fonts.sans,
              fontSize: 12,
              color: `${colors.parchment}40`,
              textDecoration: "none",
              transition: "color 0.25s",
            }}
            onMouseEnter={(e) => ((e.target as HTMLElement).style.color = colors.parchment)}
            onMouseLeave={(e) => ((e.target as HTMLElement).style.color = `${colors.parchment}40`)}
          >
            Privacy
          </Link>
          <Link
            to="/terms-of-service"
            style={{
              fontFamily: fonts.sans,
              fontSize: 12,
              color: `${colors.parchment}40`,
              textDecoration: "none",
              transition: "color 0.25s",
            }}
            onMouseEnter={(e) => ((e.target as HTMLElement).style.color = colors.parchment)}
            onMouseLeave={(e) => ((e.target as HTMLElement).style.color = `${colors.parchment}40`)}
          >
            Terms
          </Link>
          <a
            href="mailto:hello@yardfront.com"
            style={{
              fontFamily: fonts.sans,
              fontSize: 12,
              color: `${colors.parchment}40`,
              textDecoration: "none",
              transition: "color 0.25s",
            }}
            onMouseEnter={(e) => ((e.target as HTMLElement).style.color = colors.parchment)}
            onMouseLeave={(e) => ((e.target as HTMLElement).style.color = `${colors.parchment}40`)}
          >
            Contact
          </a>
        </Col>
        <Col span={4} style={{ textAlign: "right" }}>
          <span
            style={{
              fontFamily: fonts.sans,
              fontSize: 11,
              color: `${colors.parchment}20`,
            }}
          >
            © 2026 YardFront
          </span>
        </Col>
      </Grid>
    </footer>
  );
}
