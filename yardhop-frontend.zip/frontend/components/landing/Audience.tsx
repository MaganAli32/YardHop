import { Grid, Col } from "../ui/Grid";
import { colors, fonts, grid } from "../../lib/tokens";
import { useReveal } from "../../lib/hooks";

const SEGMENTS = [
  { title: "Estate sales", desc: "Price hundreds of items in a single afternoon. Upload in bulk, download structured valuations. Replace days of research with one session." },
  { title: "Thrift & vintage", desc: "Spot hidden value before it hits the floor. Know what to feature, bundle, or price aggressively. Data over gut instinct." },
  { title: "Insurance", desc: "Generate defensible replacement values backed by live comparable sales. Structured output feeds directly into claims workflows." },
  { title: "Collectors", desc: "Track the value of what you own. Understand market trends for things you love. Know when to buy, hold, or let go." },
  { title: "Retail buyback", desc: "Power your trade-in counter with transparent pricing. Build trust through data customers can see." },
];

export function Audience() {
  const [ref, vis] = useReveal(0.15);

  return (
    <section
      ref={ref}
      style={{
        padding: "120px 0",
        background: colors.parchment,
        overflow: "hidden",
      }}
    >
      <Grid style={{ marginBottom: 48 }}>
        <Col
          span={6}
          style={{
            opacity: vis ? 1 : 0,
            transform: vis ? "translateY(0)" : "translateY(16px)",
            transition: "all 0.7s cubic-bezier(0.16,1,0.3,1)",
          }}
        >
          <span
            style={{
              fontFamily: fonts.sans,
              fontSize: 11,
              color: colors.terra,
              fontWeight: 600,
              letterSpacing: "0.14em",
              textTransform: "uppercase",
            }}
          >
            Who it's for
          </span>
          <h2
            style={{
              fontFamily: fonts.serif,
              fontSize: 48,
              fontWeight: 400,
              color: colors.forest,
              letterSpacing: "-0.03em",
              margin: "12px 0 0",
              lineHeight: 1.1,
            }}
          >
            Built for people who
            <br />
            <em style={{ fontStyle: "italic", color: colors.terra }}>
              move things
            </em>
          </h2>
        </Col>
      </Grid>

      <div
        className="hide-scrollbar"
        style={{
          display: "flex",
          gap: 20,
          overflowX: "auto",
          paddingLeft: grid.padding,
          paddingRight: grid.padding,
          paddingBottom: 20,
        }}
      >
        {SEGMENTS.map((s, i) => (
          <div
            key={s.title}
            className="audience-card"
            style={{
              minWidth: 320,
              maxWidth: 320,
              padding: "32px 28px",
              background: colors.chalk,
              borderRadius: 14,
              border: `1px solid ${colors.forest}08`,
              flexShrink: 0,
              cursor: "default",
              opacity: vis ? 1 : 0,
              transform: vis ? "translateX(0)" : "translateX(36px)",
              transition: `all 0.7s cubic-bezier(0.16,1,0.3,1) ${0.2 + i * 0.08}s`,
            }}
          >
            <div
              style={{
                fontFamily: fonts.serif,
                fontSize: 26,
                fontWeight: 500,
                color: colors.forest,
                letterSpacing: "-0.02em",
                marginBottom: 14,
                lineHeight: 1.2,
              }}
            >
              {s.title}
            </div>
            <p
              style={{
                fontFamily: fonts.sans,
                fontSize: 13,
                lineHeight: 1.75,
                color: colors.stone,
                fontWeight: 400,
                margin: 0,
              }}
            >
              {s.desc}
            </p>
          </div>
        ))}
      </div>
    </section>
  );
}
