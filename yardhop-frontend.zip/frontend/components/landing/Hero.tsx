import { Grid, Col } from "../ui/Grid";
import { AnimatedWord } from "../ui/AnimatedWord";
import { BackgroundPaths } from "../backgrounds/BackgroundPaths";
import { SafariMockup } from "./SafariMockup";
import { colors, fonts } from "../../lib/tokens";
import { useEntrance } from "../../lib/hooks";
import { scrollToSection } from "../../lib/scrollToSection";

export function Hero() {
  const on = useEntrance(150);

  return (
    <section
      style={{
        minHeight: "100vh",
        display: "flex",
        alignItems: "center",
        padding: "100px 0 80px",
        background: colors.parchment,
        position: "relative",
        overflow: "hidden",
      }}
    >
      {/* ── Background Layers ── */}
      <BackgroundPaths />

      {/* Diagonal texture */}
      <div
        style={{
          position: "absolute",
          inset: 0,
          backgroundImage: `repeating-linear-gradient(-45deg, transparent, transparent 40px, ${colors.stone}06 40px, ${colors.stone}06 41px)`,
          pointerEvents: "none",
        }}
      />

      {/* Ambient blurs */}
      <div
        className="ambient-drift-1"
        style={{
          position: "absolute",
          top: "-10%",
          right: "-5%",
          width: "55vw",
          height: "55vw",
          borderRadius: "50%",
          background: `radial-gradient(circle, ${colors.terra}0A 0%, transparent 70%)`,
          pointerEvents: "none",
          filter: "blur(80px)",
          opacity: on ? 1 : 0,
          transition: "opacity 2s ease 0.3s",
          willChange: "transform",
          transform: "translateZ(0)",
        }}
      />
      <div
        className="ambient-drift-2"
        style={{
          position: "absolute",
          bottom: "-15%",
          left: "-8%",
          width: "45vw",
          height: "45vw",
          borderRadius: "50%",
          background: `radial-gradient(circle, ${colors.stone}12 0%, transparent 70%)`,
          pointerEvents: "none",
          filter: "blur(80px)",
          opacity: on ? 1 : 0,
          transition: "opacity 2s ease 0.5s",
          willChange: "transform",
          transform: "translateZ(0)",
        }}
      />

      {/* Decorative floating shapes */}
      <div
        className="float-slow"
        style={{
          position: "absolute",
          top: "14%",
          right: "10%",
          width: 260,
          height: 260,
          borderRadius: "50%",
          background: `radial-gradient(circle at 40% 40%, ${colors.terra}14, ${colors.terra}03)`,
          pointerEvents: "none",
          opacity: on ? 1 : 0,
          transition: "opacity 1.5s ease 0.4s",
          willChange: "transform",
        }}
      />
      <div
        className="float-slow-rev"
        style={{
          position: "absolute",
          bottom: "20%",
          left: "42%",
          width: 60,
          height: 60,
          borderRadius: "50%",
          border: `1.5px solid ${colors.forest}12`,
          pointerEvents: "none",
          opacity: on ? 1 : 0,
          transition: "opacity 1.2s ease 0.7s",
          willChange: "transform",
        }}
      />

      {/* ── Content Grid ── */}
      <Grid style={{ alignItems: "center", position: "relative", zIndex: 1 }}>
        {/* Text — 5 cols */}
        <Col
          span={5}
          style={{
            opacity: on ? 1 : 0,
            transform: on ? "translateY(0)" : "translateY(24px)",
            transition: "all 1s cubic-bezier(0.16,1,0.3,1) 0.2s",
          }}
        >
          <div
            style={{
              fontFamily: fonts.sans,
              fontSize: 11,
              color: colors.terra,
              fontWeight: 600,
              letterSpacing: "0.14em",
              textTransform: "uppercase",
              marginBottom: 24,
            }}
          >
            What is anything worth?
          </div>

          <h1
            style={{
              fontFamily: fonts.serif,
              fontSize: "clamp(48px, 5.5vw, 78px)",
              fontWeight: 400,
              lineHeight: 1.0,
              color: colors.forest,
              letterSpacing: "-0.04em",
              margin: "0 0 28px",
            }}
          >
            <AnimatedWord word="The" wordIndex={0} delayOffset={0.2} />
            <AnimatedWord word="answer" wordIndex={1} delayOffset={0.2} />
            <br />
            <AnimatedWord word="lives" wordIndex={2} delayOffset={0.2} />
            <AnimatedWord word="in" wordIndex={3} delayOffset={0.2} />
            <AnimatedWord word="the" wordIndex={4} delayOffset={0.2} />
            <br />
            <AnimatedWord
              word="market"
              wordIndex={5}
              delayOffset={0.2}
              isItalic
              isTerra
            />
          </h1>

          <p
            style={{
              fontFamily: fonts.sans,
              fontSize: 16,
              lineHeight: 1.75,
              color: colors.stone,
              maxWidth: 400,
              margin: "0 0 40px",
              fontWeight: 400,
            }}
          >
            YardFront reads the secondhand economy in real time. Point,
            understand, decide — all before you commit.
          </p>

          <div style={{ display: "flex", gap: 14, alignItems: "center" }}>
            <button
              type="button"
              className="cta-primary"
              onClick={() => scrollToSection("try")}
              style={{
                fontFamily: fonts.sans,
                fontSize: 14,
                fontWeight: 600,
                color: colors.chalk,
                background: colors.forest,
                border: "none",
                borderRadius: 50,
                padding: "16px 36px",
                cursor: "pointer",
                boxShadow: `0 12px 28px -6px ${colors.forest}30`,
              }}
            >
              Discover value
            </button>
            <button
              type="button"
              className="link-underline"
              onClick={() => scrollToSection("try")}
              style={{
                fontFamily: fonts.sans,
                fontSize: 13,
                color: colors.stone,
                textDecoration: "none",
                fontWeight: 500,
                borderBottom: `1px solid ${colors.stone}40`,
                paddingBottom: 2,
                background: "none",
                cursor: "pointer",
              }}
            >
              See it in action ↓
            </button>
          </div>
        </Col>

        {/* Safari mockup — 7 cols */}
        <Col span={7} style={{ position: "relative" }}>
          {/* Tilted background layer */}
          <div
            style={{
              position: "absolute",
              top: -16,
              right: -24,
              bottom: 16,
              left: 24,
              background: `${colors.stone}10`,
              borderRadius: 14,
              transform: on ? "rotate(2.5deg)" : "rotate(0deg)",
              opacity: on ? 1 : 0,
              transition: "all 1.4s cubic-bezier(0.16,1,0.3,1) 0.4s",
              border: `1px solid ${colors.stone}15`,
              backgroundImage: `radial-gradient(${colors.stone}22 1px, transparent 1px)`,
              backgroundSize: "12px 12px",
            }}
          />
          {/* Glow */}
          <div
            style={{
              position: "absolute",
              inset: 0,
              background: `linear-gradient(135deg, ${colors.terra}15, transparent)`,
              borderRadius: 14,
              filter: "blur(30px)",
              opacity: on ? 1 : 0,
              transition: "opacity 1.5s ease 0.6s",
              transform: "translate(16px, 24px)",
            }}
          />
          <div style={{ position: "relative", zIndex: 2 }}>
            <SafariMockup visible={on} />
          </div>
        </Col>
      </Grid>

      {/* Scroll indicator */}
      <div
        style={{
          position: "absolute",
          bottom: 28,
          left: "50%",
          transform: "translateX(-50%)",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          gap: 6,
          opacity: on ? 0.35 : 0,
          transition: "opacity 1s 1.4s",
        }}
      >
        <span
          style={{
            fontFamily: fonts.sans,
            fontSize: 10,
            color: colors.stone,
            letterSpacing: "0.12em",
            textTransform: "uppercase",
          }}
        >
          Scroll
        </span>
        <div
          className="pulse-down"
          style={{ width: 1, height: 28, background: colors.stone }}
        />
      </div>
    </section>
  );
}
