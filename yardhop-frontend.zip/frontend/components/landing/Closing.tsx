import { Grid, Col } from "../ui/Grid";
import { colors, fonts } from "../../lib/tokens";
import { useReveal } from "../../lib/hooks";
import { scrollToSection } from "../../lib/scrollToSection";

export function Closing() {
  const [ref, vis] = useReveal(0.2);

  return (
    <section
      ref={ref}
      style={{
        padding: "160px 0",
        background: colors.parchment,
        textAlign: "center",
        position: "relative",
      }}
    >
      {/* Decorative circles */}
      <div
        style={{
          position: "absolute",
          top: "50%",
          left: "50%",
          width: 500,
          height: 500,
          borderRadius: "50%",
          border: `1px solid ${colors.forest}06`,
          transform: "translate(-50%, -50%)",
          pointerEvents: "none",
        }}
      />
      <div
        style={{
          position: "absolute",
          top: "50%",
          left: "50%",
          width: 340,
          height: 340,
          borderRadius: "50%",
          border: `1px solid ${colors.terra}0A`,
          transform: "translate(-50%, -50%)",
          pointerEvents: "none",
        }}
      />

      <Grid>
        <Col
          span={8}
          start={3}
          style={{
            position: "relative",
            zIndex: 1,
            opacity: vis ? 1 : 0,
            transform: vis ? "translateY(0)" : "translateY(28px)",
            transition: "all 1s cubic-bezier(0.16,1,0.3,1)",
          }}
        >
          <h2
            style={{
              fontFamily: fonts.serif,
              fontSize: "clamp(40px, 5vw, 60px)",
              fontWeight: 400,
              color: colors.forest,
              letterSpacing: "-0.03em",
              margin: 0,
              lineHeight: 1.15,
            }}
          >
            You already know
            <br />
            it's worth{" "}
            <em style={{ fontStyle: "italic", color: colors.terra }}>
              something
            </em>
          </h2>
          <p
            style={{
              fontFamily: fonts.sans,
              fontSize: 16,
              lineHeight: 1.75,
              color: colors.stone,
              margin: "24px auto 40px",
              maxWidth: 380,
              fontWeight: 400,
            }}
          >
            Let us tell you exactly how much.
          </p>
          <button
            type="button"
            className="cta-primary"
            onClick={() => scrollToSection("try")}
            style={{
              fontFamily: fonts.sans,
              fontSize: 15,
              fontWeight: 600,
              color: colors.chalk,
              background: colors.forest,
              border: "none",
              borderRadius: 50,
              padding: "18px 44px",
              cursor: "pointer",
              boxShadow: `0 12px 28px -6px ${colors.forest}30`,
            }}
          >
            Start for free
          </button>
          <div
            style={{
              fontFamily: fonts.sans,
              fontSize: 12,
              color: colors.stone,
              marginTop: 16,
            }}
          >
            No account needed to try your first valuation
          </div>
        </Col>
      </Grid>
    </section>
  );
}
