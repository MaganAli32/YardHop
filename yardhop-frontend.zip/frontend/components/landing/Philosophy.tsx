import { Grid, Col } from "../ui/Grid";
import { colors, fonts } from "../../lib/tokens";
import { useReveal } from "../../lib/hooks";

export function Philosophy() {
  const [ref, vis] = useReveal(0.25);

  return (
    <section id="about" ref={ref} style={{ padding: "140px 0", background: colors.forest }}>
      <Grid>
        <Col
          span={8}
          start={3}
          style={{
            textAlign: "center",
            opacity: vis ? 1 : 0,
            transform: vis ? "translateY(0)" : "translateY(28px)",
            transition: "all 1s cubic-bezier(0.16,1,0.3,1)",
          }}
        >
          <div
            style={{
              fontFamily: fonts.serif,
              fontSize: "clamp(26px, 3.5vw, 44px)",
              fontWeight: 400,
              fontStyle: "italic",
              color: colors.parchment,
              lineHeight: 1.45,
              letterSpacing: "-0.02em",
            }}
          >
            "Every secondhand item has a story. We read what the market is
            telling about it —
            <span style={{ color: colors.terra }}> right now</span>, across
            every platform that matters."
          </div>
          <div
            style={{
              width: 48,
              height: 1.5,
              background: colors.terra,
              margin: "40px auto 0",
              opacity: vis ? 1 : 0,
              transition: "opacity 0.8s 0.5s",
            }}
          />
        </Col>
      </Grid>
    </section>
  );
}
