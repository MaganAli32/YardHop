import { Link } from "react-router-dom";
import { colors, fonts } from "../../lib/tokens";
import { Grid, Col } from "../ui/Grid";
import { useReveal } from "../../lib/hooks";

/**
 * Pricing blocks — consumer + API tiers; id for nav hash.
 * Serves as the product "price card" surface (no separate PriceCard component).
 */
export function PricingSection() {
  const [ref, vis] = useReveal(0.12);

  return (
    <section
      ref={ref}
      id="pricing"
      style={{
        padding: "120px 0 128px",
        background: colors.cream,
        borderTop: `1px solid ${colors.mist}`,
      }}
    >
      <div
        style={{
          opacity: vis ? 1 : 0,
          transform: vis ? "translateY(0)" : "translateY(20px)",
          transition: "all 0.8s cubic-bezier(0.16,1,0.3,1)",
        }}
      >
        <Grid style={{ marginBottom: 48 }}>
          <Col span={12} style={{ textAlign: "center" }}>
            <p
              style={{
                fontFamily: fonts.sans,
                fontSize: 11,
                color: colors.terracotta,
                fontWeight: 600,
                letterSpacing: "0.14em",
                textTransform: "uppercase",
                marginBottom: 12,
              }}
            >
              For Individuals
            </p>
            <h2
              style={{
                fontFamily: fonts.serif,
                fontSize: "clamp(32px,4vw,48px)",
                fontStyle: "italic",
                fontWeight: 400,
                color: colors.ink,
                margin: "0 0 12px",
              }}
            >
              Start free. Upgrade when ready.
            </h2>
            <p style={{ fontFamily: fonts.sans, fontSize: 16, color: colors.stone, maxWidth: 480, margin: "0 auto" }}>
              Get instant appraisals for anything you want to sell.
            </p>
          </Col>
        </Grid>

        <div className="max-w-2xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-4 px-6 md:px-0">
          <div
            className="p-7 rounded-sm shadow-sm"
            style={{ background: colors.parchment, border: `1px solid ${colors.mist}` }}
          >
            <p className="text-sm font-semibold mb-1" style={{ color: colors.stone }}>
              Free
            </p>
            <div className="flex items-baseline gap-1 mb-1 font-mono">
              <span className="text-4xl font-semibold" style={{ color: colors.forest }}>
                $0
              </span>
            </div>
            <p className="text-sm mb-6" style={{ color: colors.stone }}>
              5 appraisals per month
            </p>
            <ul className="space-y-2.5 mb-7">
              {[
                "Photo upload appraisals",
                "Price range with confidence score",
                "eBay + Mercari comparables",
                "Appraisal history (last 30 days)",
              ].map((f) => (
                <li key={f} className="flex items-start gap-2 text-sm" style={{ color: colors.forest }}>
                  <span className="mt-0.5 shrink-0" style={{ color: colors.terracotta }}>
                    ✓
                  </span>
                  {f}
                </li>
              ))}
            </ul>
            <Link
              to="/signup"
              className="block w-full text-center py-3 rounded-sm text-sm font-medium transition-colors no-underline border"
              style={{
                borderColor: colors.forest,
                color: colors.forest,
              }}
            >
              Get started free
            </Link>
          </div>

          <div
            className="p-7 relative rounded-sm shadow-sm"
            style={{ background: colors.forest, border: `1px solid ${colors.mist}` }}
          >
            <span
              className="absolute -top-3 left-6 text-xs font-bold px-3 py-1 rounded-sm"
              style={{ background: colors.terracotta, color: colors.cream }}
            >
              Most Popular
            </span>
            <p className="text-sm font-semibold mb-1" style={{ color: `${colors.parchment}99` }}>
              Pro
            </p>
            <div className="flex items-baseline gap-1 mb-1 font-mono">
              <span className="text-4xl font-semibold" style={{ color: colors.parchment }}>
                $9.99
              </span>
              <span className="text-sm" style={{ color: `${colors.parchment}66` }}>
                /mo
              </span>
            </div>
            <p className="text-sm mb-6" style={{ color: `${colors.parchment}99` }}>
              Unlimited appraisals
            </p>
            <ul className="space-y-2.5 mb-7">
              {[
                "Everything in Free",
                "Unlimited appraisals",
                "Full appraisal history",
                "5+ data sources",
                "Best platform recommendations",
                "Price trend alerts",
              ].map((f) => (
                <li key={f} className="flex items-start gap-2 text-sm" style={{ color: `${colors.parchment}cc` }}>
                  <span className="mt-0.5 shrink-0" style={{ color: colors.terracotta }}>
                    ✓
                  </span>
                  {f}
                </li>
              ))}
            </ul>
            <Link
              to="/signup?plan=pro"
              className="block w-full text-center py-3 rounded-sm text-sm font-medium transition-colors no-underline"
              style={{ background: colors.parchment, color: colors.forest }}
            >
              Start free trial
            </Link>
          </div>
        </div>

        <div className="max-w-[1200px] mx-auto px-6 mt-20 pt-16" style={{ borderTop: `1px solid ${colors.mist}` }}>
          <p
            className="text-center text-xs font-semibold tracking-[0.2em] uppercase mb-3"
            style={{ color: colors.terracotta }}
          >
            For Businesses
          </p>
          <h3
            className="text-center italic text-3xl lg:text-4xl mb-3"
            style={{ fontFamily: fonts.serif, fontWeight: 400, color: colors.ink }}
          >
            API access for teams.
          </h3>
          <p className="text-center text-lg mb-10 max-w-xl mx-auto" style={{ color: colors.stone }}>
            Estate sale companies, thrift chains, insurance appraisers. Price inventory at scale.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            {[
              { name: "Starter", price: "$99", limit: "500 appraisals/mo", popular: false },
              { name: "Growth", price: "$299", limit: "2,000 appraisals/mo", popular: true },
              { name: "Scale", price: "$799", limit: "7,500 appraisals/mo", popular: false },
            ].map((tier) => (
              <div
                key={tier.name}
                className="rounded-sm p-6 relative shadow-sm"
                style={
                  tier.popular
                    ? { background: colors.forest, border: `1px solid ${colors.mist}` }
                    : { background: colors.parchment, border: `1px solid ${colors.mist}` }
                }
              >
                {tier.popular && (
                  <span
                    className="absolute -top-3 left-5 text-xs font-bold px-3 py-1 rounded-sm"
                    style={{ background: colors.terracotta, color: colors.cream }}
                  >
                    Popular
                  </span>
                )}
                <p
                  className="text-sm font-semibold mb-1"
                  style={{ color: tier.popular ? `${colors.parchment}99` : colors.stone }}
                >
                  {tier.name}
                </p>
                <div className="flex items-baseline gap-1 font-mono">
                  <span
                    className={`text-3xl font-semibold ${tier.popular ? "" : ""}`}
                    style={{ color: tier.popular ? colors.parchment : colors.forest }}
                  >
                    {tier.price}
                  </span>
                  <span className="text-sm" style={{ color: tier.popular ? `${colors.parchment}66` : colors.stone }}>
                    /mo
                  </span>
                </div>
                <p className="text-xs mb-4" style={{ color: tier.popular ? `${colors.parchment}99` : colors.stone }}>
                  {tier.limit}
                </p>
                <Link
                  to="/business#waitlist"
                  className="block w-full text-center py-2.5 rounded-sm text-sm font-medium no-underline transition-opacity hover:opacity-90"
                  style={
                    tier.popular
                      ? { background: colors.parchment, color: colors.forest }
                      : { border: `1px solid ${colors.forest}`, color: colors.forest }
                  }
                >
                  Join waitlist
                </Link>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
