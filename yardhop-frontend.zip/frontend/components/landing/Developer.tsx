import { Grid, Col } from "../ui/Grid";
import { colors, fonts } from "../../lib/tokens";
import { useReveal } from "../../lib/hooks";

const CODE_SNIPPET = `$ curl yardfront.com/v1/value \\
    -F image=@photo.jpg

→ {
    item: "Mid-century teak credenza"
    maker: "likely Danish, c.1960s"
    value: 1250
    range: [900, 1600]
    confidence: 0.91
  }`;

export function Developer() {
  const [ref, vis] = useReveal(0.15);

  return (
    <section ref={ref} style={{ padding: "120px 0", background: colors.chalk }}>
      <Grid style={{ alignItems: "center" }}>
        {/* Prose */}
        <Col
          span={5}
          style={{
            opacity: vis ? 1 : 0,
            transform: vis ? "translateX(0)" : "translateX(-18px)",
            transition: "all 0.9s cubic-bezier(0.16,1,0.3,1) 0.1s",
          }}
        >
          <span
            style={{
              fontFamily: fonts.sans,
              fontSize: 11,
              color: colors.terra,
              fontWeight: 600,
              letterSpacing: "0.14em",
              textTransform: "uppercase",
            }}
          >
            For developers
          </span>
          <h2
            style={{
              fontFamily: fonts.serif,
              fontSize: 44,
              fontWeight: 400,
              color: colors.forest,
              letterSpacing: "-0.03em",
              margin: "12px 0 18px",
              lineHeight: 1.15,
            }}
          >
            One call.
            <br />
            <em style={{ fontStyle: "italic", color: colors.terra }}>
              Everything
            </em>{" "}
            back.
          </h2>
          <div
            style={{
              fontFamily: fonts.sans,
              fontSize: 15,
              lineHeight: 1.8,
              color: colors.stone,
              fontWeight: 400,
            }}
          >
            <p style={{ margin: "0 0 14px" }}>
              Send us an image. We return a structured valuation — item
              identity, a confidence-weighted price range, and the raw
              comparable listings we used to get there.
            </p>
            <p style={{ margin: 0 }}>
              No SDK. No webhook setup. No batch jobs. One REST endpoint.
              JSON in, JSON out.
            </p>
          </div>
        </Col>

        {/* Terminal */}
        <Col
          span={6}
          start={7}
          style={{
            opacity: vis ? 1 : 0,
            transform: vis ? "translateX(0)" : "translateX(18px)",
            transition: "all 0.9s cubic-bezier(0.16,1,0.3,1) 0.25s",
          }}
        >
          <div
            style={{
              background: colors.forest,
              borderRadius: 14,
              overflow: "hidden",
            }}
          >
            <div
              style={{
                padding: "12px 18px",
                borderBottom: `1px solid ${colors.parchment}0C`,
                display: "flex",
                alignItems: "center",
                gap: 7,
              }}
            >
              {[colors.terra, "#E2A63D", "#51B958"].map((c, i) => (
                <div
                  key={i}
                  style={{
                    width: 9,
                    height: 9,
                    borderRadius: "50%",
                    background: c,
                    opacity: 0.65,
                  }}
                />
              ))}
              <span
                style={{
                  fontFamily: fonts.sans,
                  fontSize: 10,
                  color: `${colors.parchment}28`,
                  marginLeft: 6,
                }}
              >
                terminal
              </span>
            </div>
            <div style={{ padding: "20px 22px 24px" }}>
              <pre
                style={{
                  margin: 0,
                  fontFamily: fonts.mono,
                  fontSize: 12.5,
                  lineHeight: 2.0,
                  color: `${colors.parchment}BB`,
                  whiteSpace: "pre-wrap",
                }}
              >
                {CODE_SNIPPET}
              </pre>
            </div>
          </div>
          <p
            style={{
              fontFamily: fonts.sans,
              fontSize: 12,
              color: colors.stone,
              marginTop: 12,
              textAlign: "center",
            }}
          >
            That's the whole integration.
          </p>
        </Col>
      </Grid>
    </section>
  );
}
