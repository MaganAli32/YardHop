import { useState, useRef, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Camera } from "lucide-react";
import { Grid, Col } from "../ui/Grid";
import { colors, fonts } from "../../lib/tokens";
import { useReveal } from "../../lib/hooks";
import { getBrowserFingerprint } from "../../lib/fingerprint";
import { usePersistence } from "../../store/PersistenceContext";
import { scrollToSection } from "../../lib/scrollToSection";

const MAX_FILE_SIZE = 10 * 1024 * 1024;
const ACCEPT_IMAGES = "image/jpeg,image/png,image/heic,image/webp";

type UsageState = {
  used: number;
  limit: number;
  remaining: number;
  is_limited: boolean;
};

export function TryIt() {
  const [ref, vis] = useReveal(0.15);
  const navigate = useNavigate();
  const { authToken } = usePersistence();
  const fileRef = useRef<HTMLInputElement>(null);
  const [hover, setHover] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [usage, setUsage] = useState<UsageState>({
    used: 0,
    limit: 3,
    remaining: 3,
    is_limited: false,
  });

  useEffect(() => {
    const headers: Record<string, string> = { "X-Fingerprint": getBrowserFingerprint() };
    if (authToken) headers.Authorization = `Bearer ${authToken}`;
    fetch("/api/usage", { headers })
      .then((r) => r.json())
      .then((data) =>
        setUsage({
          used: data.used ?? 0,
          limit: data.limit ?? 3,
          remaining: data.remaining ?? 3,
          is_limited: data.is_limited ?? false,
        })
      )
      .catch(() => {});
  }, [authToken]);

  const busy = isUploading;

  const handleFile = async (file: File) => {
    setUploadError(null);
    if (file.size > MAX_FILE_SIZE) {
      setUploadError("Please use an image under 10MB.");
      return;
    }
    if (!file.type.startsWith("image/")) {
      setUploadError("Please upload an image (JPG, PNG, HEIC).");
      return;
    }
    setIsUploading(true);
    const formData = new FormData();
    formData.append("image", file);
    const headers: Record<string, string> = { "X-Fingerprint": getBrowserFingerprint() };
    if (authToken) headers.Authorization = `Bearer ${authToken}`;
    try {
      const response = await fetch("/api/appraise", { method: "POST", body: formData, headers });
      const data = await response.json().catch(() => ({}));
      if (response.status === 403 && data?.error === "free_limit_reached") {
        setUsage((p) => ({ ...p, is_limited: true, remaining: 0 }));
        setUploadError("You've used all free appraisals. See plans below.");
        return;
      }
      if (!response.ok) {
        throw new Error(data?.error || data?.message || `Appraisal failed (${response.status})`);
      }
      sessionStorage.setItem("appraisalResult", JSON.stringify(data));
      setUsage((p) => ({
        ...p,
        used: p.used + 1,
        remaining: Math.max(0, p.remaining - 1),
        is_limited: p.used + 1 >= p.limit,
      }));
      navigate("/appraise/results");
    } catch (e) {
      setUploadError(e instanceof Error ? e.message : "Something went wrong.");
    } finally {
      setIsUploading(false);
    }
  };

  const openPicker = () => {
    if (busy || usage.is_limited) return;
    fileRef.current?.click();
  };

  const onChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (f) handleFile(f);
    e.target.value = "";
  };

  const onDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const f = e.dataTransfer.files?.[0];
    if (f && f.type.startsWith("image/")) handleFile(f);
    else setUploadError("Drop an image file (JPG, PNG, HEIC).");
  };

  return (
    <section
      ref={ref}
      id="try"
      style={{
        padding: "120px 0",
        background: colors.parchment,
        borderTop: `1px solid ${colors.stone}15`,
        borderBottom: `1px solid ${colors.stone}15`,
      }}
    >
      <input ref={fileRef} type="file" accept={ACCEPT_IMAGES} capture="environment" className="hidden" onChange={onChange} />

      <Grid>
        <Col
          span={4}
          style={{
            display: "flex",
            flexDirection: "column",
            justifyContent: "center",
            opacity: vis ? 1 : 0,
            transform: vis ? "translateX(0)" : "translateX(-20px)",
            transition: "all 0.8s cubic-bezier(0.16,1,0.3,1) 0.1s",
          }}
        >
          <div
            style={{
              fontFamily: fonts.sans,
              fontSize: 11,
              color: colors.terra,
              fontWeight: 600,
              letterSpacing: "0.14em",
              textTransform: "uppercase",
              marginBottom: 16,
            }}
          >
            Try it yourself
          </div>
          <h2
            style={{
              fontFamily: fonts.serif,
              fontSize: 44,
              fontWeight: 400,
              color: colors.forest,
              letterSpacing: "-0.03em",
              margin: "0 0 16px",
              lineHeight: 1.1,
            }}
          >
            See it
            <br />
            <em style={{ fontStyle: "italic", color: colors.terra }}>work</em>
          </h2>
          <p
            style={{
              fontFamily: fonts.sans,
              fontSize: 14,
              lineHeight: 1.75,
              color: colors.stone,
              fontWeight: 400,
              margin: "0 0 28px",
            }}
          >
            Upload a real photo — we&apos;ll run the same appraisal pipeline used in the product. Typical response in a few seconds.
          </p>

          <div
            style={{
              fontFamily: fonts.mono,
              fontSize: 11,
              color: colors.stone,
              lineHeight: 1.8,
              padding: "16px 18px",
              background: colors.chalk,
              borderRadius: 8,
              border: `1px solid ${colors.stone}12`,
            }}
          >
            <div style={{ color: `${colors.stone}88` }}>{"// Free tier"}</div>
            <div>
              <span style={{ color: colors.terra }}>appraisals</span>: limited / mo
            </div>
            <div>
              <span style={{ color: colors.terra }}>card</span>: not required
            </div>
            <div>
              <span style={{ color: colors.terra }}>signup</span>: optional
            </div>
          </div>
        </Col>

        <Col
          span={7}
          start={6}
          style={{
            opacity: vis ? 1 : 0,
            transform: vis ? "translateY(0)" : "translateY(20px)",
            transition: "all 0.8s cubic-bezier(0.16,1,0.3,1) 0.25s",
          }}
        >
          <div
            style={{
              background: colors.chalk,
              borderRadius: 16,
              border: `1px solid ${colors.stone}18`,
              overflow: "hidden",
              boxShadow: `0 24px 64px -16px ${colors.forest}12`,
            }}
          >
            <div
              style={{
                padding: "14px 20px",
                borderBottom: `1px solid ${colors.stone}12`,
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
              }}
            >
              <span
                style={{
                  fontFamily: fonts.sans,
                  fontSize: 12,
                  color: colors.forest,
                  fontWeight: 600,
                }}
              >
                Live appraisal
              </span>
              <div
                style={{
                  width: 8,
                  height: 8,
                  borderRadius: "50%",
                  background: isUploading ? "#E8A33A" : `${colors.stone}40`,
                  boxShadow: isUploading ? "0 0 8px #E8A33A88" : "none",
                  transition: "all 0.4s",
                }}
              />
            </div>

            {usage.is_limited ? (
              <div style={{ padding: 40, textAlign: "center" }}>
                <p style={{ fontFamily: fonts.sans, fontSize: 15, color: colors.forest, fontWeight: 600, marginBottom: 8 }}>
                  Free appraisals used
                </p>
                <p style={{ fontFamily: fonts.sans, fontSize: 13, color: colors.stone, marginBottom: 20 }}>
                  Upgrade or view plans to keep going.
                </p>
                <button
                  type="button"
                  className="cta-primary"
                  onClick={() => scrollToSection("pricing")}
                  style={{
                    fontFamily: fonts.sans,
                    fontSize: 14,
                    fontWeight: 600,
                    color: colors.chalk,
                    background: colors.forest,
                    border: "none",
                    borderRadius: 50,
                    padding: "12px 28px",
                    cursor: "pointer",
                  }}
                >
                  View pricing
                </button>
              </div>
            ) : (
              <div
                style={{
                  padding: 24,
                  display: "flex",
                  gap: 24,
                  minHeight: 320,
                }}
              >
                <div
                  role="button"
                  tabIndex={0}
                  onClick={() => {
                    if (uploadError) setUploadError(null);
                    openPicker();
                  }}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" || e.key === " ") {
                      e.preventDefault();
                      openPicker();
                    }
                  }}
                  onDrop={onDrop}
                  onDragOver={(e) => {
                    e.preventDefault();
                    setIsDragging(true);
                  }}
                  onDragLeave={() => setIsDragging(false)}
                  onMouseEnter={() => setHover(true)}
                  onMouseLeave={() => setIsDragging(false)}
                  style={{
                    flex: 1,
                    borderRadius: 10,
                    border: `2px dashed ${
                      isDragging || isUploading ? colors.terra : hover ? colors.terra : `${colors.stone}30`
                    }`,
                    background: isDragging ? `${colors.terra}08` : hover ? `${colors.terra}06` : `${colors.stone}06`,
                    display: "flex",
                    flexDirection: "column",
                    alignItems: "center",
                    justifyContent: "center",
                    cursor: busy ? "default" : "pointer",
                    transition: "all 0.35s",
                    gap: 12,
                  }}
                >
                  {isUploading ? (
                    <div style={{ textAlign: "center" }}>
                      <div className="spinner" />
                      <span
                        style={{
                          fontFamily: fonts.sans,
                          fontSize: 13,
                          color: colors.forest,
                          fontWeight: 500,
                        }}
                      >
                        Scanning markets…
                      </span>
                    </div>
                  ) : (
                    <>
                      <div
                        style={{
                          width: 52,
                          height: 52,
                          borderRadius: 12,
                          background: colors.parchment,
                          border: `1px solid ${colors.stone}20`,
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "center",
                          color: hover ? colors.terra : colors.stone,
                          transform: hover ? "scale(1.08)" : "scale(1)",
                          transition: "transform 0.3s",
                        }}
                      >
                        <Camera size={22} strokeWidth={2} />
                      </div>
                      <span
                        style={{
                          fontFamily: fonts.sans,
                          fontSize: 13,
                          color: hover ? colors.forest : colors.stone,
                          fontWeight: 500,
                        }}
                      >
                        Tap or drop a photo
                      </span>
                      {uploadError && (
                        <span style={{ fontFamily: fonts.sans, fontSize: 12, color: "#b91c1c", textAlign: "center", padding: "0 12px" }}>
                          {uploadError}
                        </span>
                      )}
                    </>
                  )}
                </div>

                <div
                  style={{
                    flex: 1.1,
                    display: "flex",
                    flexDirection: "column",
                    opacity: 0.35,
                  }}
                >
                  <div
                    style={{
                      fontFamily: fonts.sans,
                      fontSize: 10,
                      color: colors.terra,
                      textTransform: "uppercase",
                      letterSpacing: "0.1em",
                      marginBottom: 10,
                    }}
                  >
                    Preview
                  </div>
                  <div
                    style={{
                      fontFamily: fonts.serif,
                      fontSize: 24,
                      color: colors.forest,
                      lineHeight: 1.2,
                      marginBottom: 4,
                    }}
                  >
                    Leather Weekender Bag
                  </div>
                  <div style={{ fontFamily: fonts.sans, fontSize: 11, color: colors.stone, marginBottom: 20 }}>
                    Example result · your item will vary
                  </div>
                  <div
                    style={{
                      padding: "16px 18px",
                      borderRadius: 8,
                      background: colors.parchment,
                      border: `1px solid ${colors.stone}10`,
                      marginBottom: 12,
                    }}
                  >
                    <div
                      style={{
                        fontFamily: fonts.sans,
                        fontSize: 32,
                        fontWeight: 300,
                        color: colors.forest,
                        letterSpacing: "-0.02em",
                      }}
                    >
                      $85
                    </div>
                    <div style={{ fontFamily: fonts.sans, fontSize: 12, color: colors.stone, marginTop: 2 }}>Range: $60 – $120</div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </Col>
      </Grid>
    </section>
  );
}
