import { Link } from "react-router-dom";
import { Grid, Col } from "../ui/Grid";
import { colors, fonts } from "../../lib/tokens";
import { useScrolled } from "../../lib/hooks";
import { scrollToSection } from "../../lib/scrollToSection";

export function Nav() {
  const scrolled = useScrolled(60);

  return (
    <nav
      style={{
        position: "fixed",
        top: 0,
        left: 0,
        right: 0,
        zIndex: 100,
        padding: scrolled ? "14px 0" : "22px 0",
        background: scrolled ? `${colors.parchment}F0` : "transparent",
        backdropFilter: scrolled ? "blur(14px)" : "none",
        transition: "all 0.4s ease",
      }}
    >
      <Grid style={{ alignItems: "center" }}>
        <Col span={2}>
          <Link
            to="/"
            style={{
              fontFamily: fonts.serif,
              fontSize: 24,
              fontWeight: 600,
              color: colors.forest,
              textDecoration: "none",
            }}
          >
            yf.
          </Link>
        </Col>
        <Col
          span={10}
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "flex-end",
            gap: 40,
            flexWrap: "wrap",
          }}
        >
          <button
            type="button"
            style={{
              fontFamily: fonts.sans,
              fontSize: 13,
              color: colors.stone,
              textDecoration: "none",
              fontWeight: 500,
              transition: "color 0.3s",
              background: "none",
              border: "none",
              cursor: "pointer",
              padding: 0,
            }}
            onMouseEnter={(e) => ((e.target as HTMLElement).style.color = colors.forest)}
            onMouseLeave={(e) => ((e.target as HTMLElement).style.color = colors.stone)}
            onClick={() => scrollToSection("about")}
          >
            About
          </button>
          <Link
            to="/business"
            style={{
              fontFamily: fonts.sans,
              fontSize: 13,
              color: colors.stone,
              textDecoration: "none",
              fontWeight: 500,
              transition: "color 0.3s",
            }}
            onMouseEnter={(e) => ((e.target as HTMLElement).style.color = colors.forest)}
            onMouseLeave={(e) => ((e.target as HTMLElement).style.color = colors.stone)}
          >
            For Business
          </Link>
          <Link
            to="/marketplace"
            style={{
              fontFamily: fonts.sans,
              fontSize: 13,
              color: colors.stone,
              textDecoration: "none",
              fontWeight: 500,
              transition: "color 0.3s",
            }}
            onMouseEnter={(e) => ((e.target as HTMLElement).style.color = colors.forest)}
            onMouseLeave={(e) => ((e.target as HTMLElement).style.color = colors.stone)}
          >
            Marketplace
          </Link>
          <button
            type="button"
            style={{
              fontFamily: fonts.sans,
              fontSize: 13,
              color: colors.stone,
              textDecoration: "none",
              fontWeight: 500,
              transition: "color 0.3s",
              background: "none",
              border: "none",
              cursor: "pointer",
              padding: 0,
            }}
            onMouseEnter={(e) => ((e.target as HTMLElement).style.color = colors.forest)}
            onMouseLeave={(e) => ((e.target as HTMLElement).style.color = colors.stone)}
            onClick={() => scrollToSection("pricing")}
          >
            Pricing
          </button>
          <Link
            to="/login"
            style={{
              fontFamily: fonts.sans,
              fontSize: 13,
              color: colors.stone,
              textDecoration: "none",
              fontWeight: 500,
            }}
          >
            Sign in
          </Link>
          <button
            type="button"
            style={{
              fontFamily: fonts.sans,
              fontSize: 13,
              color: colors.forest,
              textDecoration: "none",
              fontWeight: 600,
              borderBottom: `1.5px solid ${colors.terra}`,
              paddingBottom: 2,
              background: "none",
              borderTop: "none",
              borderLeft: "none",
              borderRight: "none",
              cursor: "pointer",
            }}
            onClick={() => scrollToSection("try")}
          >
            Try it
          </button>
        </Col>
      </Grid>
    </nav>
  );
}
