import React from "react";
import { Grid, Col } from "../ui/Grid";
import { colors, fonts, grid } from "../../lib/tokens";
import { useReveal } from "../../lib/hooks";

interface ImageBlockProps {
  h: number;
  label: string;
  delay: number;
  visible: boolean;
  bg?: string;
}

function ImageBlock({ h, label, delay, visible, bg }: ImageBlockProps) {
  return (
    <div
      style={{
        height: h,
        background: bg || colors.parchment,
        borderRadius: 12,
        display: "flex",
        alignItems: "flex-end",
        padding: 22,
        position: "relative",
        overflow: "hidden",
        opacity: visible ? 1 : 0,
        transform: visible ? "translateY(0)" : "translateY(18px)",
        transition: `all 0.8s cubic-bezier(0.16,1,0.3,1) ${delay}s`,
      }}
    >
      <div
        style={{
          position: "absolute",
          inset: 0,
          backgroundImage: `radial-gradient(${colors.forest}06 1px, transparent 1px)`,
          backgroundSize: "20px 20px",
          pointerEvents: "none",
        }}
      />
      <span
        style={{
          fontFamily: fonts.sans,
          fontSize: 13,
          color: colors.bark,
          fontWeight: 500,
          position: "relative",
          lineHeight: 1.5,
        }}
      >
        {label}
      </span>
    </div>
  );
}

export function Editorial() {
  const [ref, vis] = useReveal(0.12);

  return (
    <section ref={ref} style={{ padding: "120px 0", background: colors.chalk }}>
      {/* Header */}
      <Grid style={{ marginBottom: 80 }}>
        <Col
          span={5}
          style={{
            opacity: vis ? 1 : 0,
            transform: vis ? "translateX(0)" : "translateX(-20px)",
            transition: "all 0.9s cubic-bezier(0.16,1,0.3,1) 0.1s",
          }}
        >
          <h2
            style={{
              fontFamily: fonts.serif,
              fontSize: 52,
              fontWeight: 400,
              color: colors.forest,
              letterSpacing: "-0.03em",
              lineHeight: 1.1,
              margin: 0,
            }}
          >
            It sees
            <br />
            what you
            <br />
            <em style={{ fontStyle: "italic", color: colors.terra }}>can't</em>
          </h2>
        </Col>
        <Col
          span={5}
          start={8}
          style={{
            display: "flex",
            alignItems: "flex-end",
            opacity: vis ? 1 : 0,
            transform: vis ? "translateX(0)" : "translateX(20px)",
            transition: "all 0.9s cubic-bezier(0.16,1,0.3,1) 0.25s",
          }}
        >
          <p
            style={{
              fontFamily: fonts.sans,
              fontSize: 15,
              lineHeight: 1.8,
              color: colors.stone,
              fontWeight: 400,
              margin: 0,
            }}
          >
            Our model doesn't just identify items — it understands what drives
            their value. Brand reputation, condition nuances, seasonal demand,
            regional pricing. All synthesized from live resale data.
          </p>
        </Col>
      </Grid>

      {/* Asymmetric image grid — row 1 */}
      <Grid>
        <Col span={8}>
          <ImageBlock
            h={380}
            label="A vintage chair. Fourteen data points extracted. Three seconds."
            delay={0.3}
            visible={vis}
          />
        </Col>
        <Col span={4}>
          <ImageBlock
            h={380}
            label="Condition analysis at the pixel level."
            delay={0.45}
            visible={vis}
            bg={`${colors.forest}06`}
          />
        </Col>
      </Grid>

      {/* Row 2 */}
      <Grid style={{ marginTop: grid.gap }}>
        <Col span={3}>
          <ImageBlock
            h={260}
            label="Brand recognition."
            delay={0.55}
            visible={vis}
            bg={`${colors.terra}0A`}
          />
        </Col>
        <Col span={6}>
          <ImageBlock
            h={260}
            label="Cross-platform price comparison — rendered instantly."
            delay={0.65}
            visible={vis}
          />
        </Col>
        <Col span={3}>
          <ImageBlock
            h={260}
            label="Confidence scoring."
            delay={0.75}
            visible={vis}
            bg={`${colors.forest}05`}
          />
        </Col>
      </Grid>
    </section>
  );
}
