/**
 * YardFront Navbar — shared across all pages
 * Logged out: Logo | Marketplace | How It Works | Pricing | Sign In | Get Started
 * Logged in:  Logo | Marketplace | How It Works | Pricing | My Account | API Dashboard | [user menu]
 */

import React, { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { usePersistence } from '../store/PersistenceContext';
import { supabase } from '../lib/supabase';

const PARCHMENT = '#F5F0E8';
const FOREST = '#2C4A3E';
const TERRA = '#C4622D';
const MIST = '#E8E2D9';

export default function Navbar() {
  const location = useLocation();
  const navigate = useNavigate();
  const { user, authToken } = usePersistence();
  const isLanding = location.pathname === '/';
  const [mobileOpen, setMobileOpen] = useState(false);

  const isLoggedIn = !!(authToken || user);

  const scrollTo = (id: string) => {
    if (isLanding) {
      document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
      setMobileOpen(false);
    } else {
      navigate(`/#${id}`);
    }
  };

  const handleSignOut = async () => {
    if (supabase) await supabase.auth.signOut();
    setMobileOpen(false);
    navigate('/');
  };

  return (
    <nav
      className="fixed top-0 left-0 right-0 z-[100] h-16 px-6 md:px-[56px] flex items-center justify-between font-['Manrope']"
      style={{
        background: `${PARCHMENT}E6`,
        backdropFilter: 'blur(24px)',
        WebkitBackdropFilter: 'blur(24px)',
        borderBottom: `1px solid ${MIST}`,
      }}
    >
      {/* Logo */}
      <Link
        to="/"
        className="text-[18px] font-medium text-[#1A1A18] tracking-[-0.02em] no-underline"
        style={{ fontFamily: "'Cormorant Garamond', serif" }}
      >
        Yard<span style={{ color: TERRA }}>Front</span>
      </Link>

      {/* Desktop Nav */}
      <div className="hidden md:flex items-center gap-8">
        <Link
          to="/marketplace"
          className="text-[14px] font-medium text-[#5c665f] hover:text-[#2C4A3E] transition-colors no-underline"
        >
          Marketplace
        </Link>
        <Link
          to="/business"
          className="text-[14px] font-medium text-[#5c665f] hover:text-[#2C4A3E] transition-colors no-underline flex items-center gap-1.5"
        >
          For Business
          <span className="text-[10px] font-semibold uppercase tracking-wider text-[#C4622D]/90">API</span>
        </Link>

        {isLanding ? (
          <>
            <button
              type="button"
              onClick={() => scrollTo('steps')}
              className="text-[14px] font-medium text-[#5c665f] hover:text-[#2C4A3E] transition-colors"
            >
              How It Works
            </button>
            <button
              type="button"
              onClick={() => scrollTo('pricing')}
              className="text-[14px] font-medium text-[#5c665f] hover:text-[#2C4A3E] transition-colors"
            >
              Pricing
            </button>
          </>
        ) : (
          <>
            <Link
              to="/#steps"
              className="text-[14px] font-medium text-[#5c665f] hover:text-[#2C4A3E] transition-colors no-underline"
            >
              How It Works
            </Link>
            <Link
              to="/#pricing"
              className="text-[14px] font-medium text-[#5c665f] hover:text-[#2C4A3E] transition-colors no-underline"
            >
              Pricing
            </Link>
          </>
        )}

        {isLoggedIn ? (
          <>
            <Link
              to="/account"
              className="text-[14px] font-medium text-[#5c665f] hover:text-[#2C4A3E] transition-colors no-underline"
            >
              My Account
            </Link>
            <Link
              to="/dashboard"
              className="text-[14px] font-medium text-[#5c665f] hover:text-[#2C4A3E] transition-colors no-underline"
            >
              API Dashboard
            </Link>
            <button
              type="button"
              onClick={handleSignOut}
              className="text-[14px] font-medium text-[#5c665f] hover:text-[#2C4A3E] transition-colors"
            >
              Sign Out
            </button>
          </>
        ) : (
          <>
            <Link
              to="/login"
              className="text-[14px] font-medium text-[#5c665f] hover:text-[#2C4A3E] transition-colors no-underline"
            >
              Sign In
            </Link>
            {isLanding ? (
              <button
                type="button"
                onClick={() => scrollTo('upload')}
                className="py-2 px-5 bg-[#2C4A3E] text-[#F5F0E8] rounded-sm text-[13px] font-semibold hover:bg-[#3a5f50] transition-colors"
              >
                Get Started
              </button>
            ) : (
              <Link
                to="/signup"
                className="py-2 px-5 bg-[#2C4A3E] text-[#F5F0E8] rounded-sm text-[13px] font-semibold hover:bg-[#3a5f50] transition-colors no-underline inline-block"
              >
                Sign Up
              </Link>
            )}
          </>
        )}
      </div>

      {/* Mobile Nav Toggle */}
      <button
        className="md:hidden p-2 text-[#1A1A18]"
        onClick={() => setMobileOpen(!mobileOpen)}
        aria-label="Menu"
      >
        {mobileOpen ? (
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M18 6L6 18M6 6l12 12" />
          </svg>
        ) : (
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M3 12h18M3 6h18M3 18h18" />
          </svg>
        )}
      </button>

      {/* Mobile Menu */}
      {mobileOpen && (
        <div
          className="absolute top-16 left-0 right-0 md:hidden rounded-sm shadow-sm"
          style={{
            background: PARCHMENT,
            borderTop: `1px solid ${MIST}`,
            borderBottom: `1px solid ${MIST}`,
            backdropFilter: 'blur(24px)',
          }}
        >
          <div className="flex flex-col p-6 gap-4">
            <Link
              to="/marketplace"
              onClick={() => setMobileOpen(false)}
              className="text-[15px] font-medium text-[#1A1A18] no-underline"
            >
              Marketplace
            </Link>
            <Link
              to="/business"
              onClick={() => setMobileOpen(false)}
              className="text-[15px] font-medium text-[#5c665f] no-underline flex items-center gap-1.5"
            >
              For Business <span className="text-[10px] font-semibold text-[#C4622D]">API</span>
            </Link>
            <button
              type="button"
              onClick={() => scrollTo('steps')}
              className="text-[15px] font-medium text-[#5c665f] text-left"
            >
              How It Works
            </button>
            <button
              type="button"
              onClick={() => scrollTo('pricing')}
              className="text-[15px] font-medium text-[#5c665f] text-left"
            >
              Pricing
            </button>

            {isLoggedIn ? (
              <>
                <Link
                  to="/account"
                  onClick={() => setMobileOpen(false)}
                  className="text-[15px] font-medium text-[#1A1A18] no-underline"
                >
                  My Account
                </Link>
                <Link
                  to="/dashboard"
                  onClick={() => setMobileOpen(false)}
                  className="text-[15px] font-medium text-[#1A1A18] no-underline"
                >
                  API Dashboard
                </Link>
                <button
                  type="button"
                  onClick={handleSignOut}
                  className="text-[15px] font-medium text-[#C4622D] text-left"
                >
                  Sign Out
                </button>
              </>
            ) : (
              <>
                <Link
                  to="/login"
                  onClick={() => setMobileOpen(false)}
                  className="text-[15px] font-medium text-[#1A1A18] no-underline"
                >
                  Sign In
                </Link>
                <Link
                  to="/signup"
                  onClick={() => setMobileOpen(false)}
                  className="block text-center py-3 bg-[#2C4A3E] text-[#F5F0E8] rounded-sm text-[13px] font-semibold no-underline hover:bg-[#3a5f50]"
                >
                  Sign Up
                </Link>
              </>
            )}
          </div>
        </div>
      )}
    </nav>
  );
}
