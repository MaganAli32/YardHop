/**
 * YardFront Design Tokens — "The Storefront"
 * ═══════════════════════════════════════════
 * Warm analog editorial — single source for TS/inline styles
 */

// ─── PALETTE (matches DESIGN_MIGRATION.md + :root in global.css) ──
export const colors = {
  parchment: "#F5F0E8",
  forest: "#2C4A3E",
  terracotta: "#C4622D",
  /** @deprecated use terracotta — kept for gradual migration */
  terra: "#C4622D",
  cream: "#FAF7F2",
  ink: "#1A1A18",
  mist: "#E8E2D9",
  stone: "#7A756D",
  chalk: "#FAF7F2",
  bark: "#3D3229",
} as const;

// ─── GRID ────────────────────────────────────────────────
export const grid = {
  maxWidth: 1200,
  gap: 24,
  padding: 52,
  columns: 12,
} as const;

// ─── TYPOGRAPHY ──────────────────────────────────────────
export const fonts = {
  serif: "'Cormorant Garamond', serif",
  sans: "'Manrope', sans-serif",
  mono: "'DM Mono', monospace",
} as const;

// ─── ANIMATION ───────────────────────────────────────────
export const ease = {
  out: [0.16, 1, 0.3, 1] as const,
  spring: { type: "spring" as const, stiffness: 150, damping: 25 },
};

export type Colors = typeof colors;
export type ColorKey = keyof Colors;
