/**
 * YardFront landing — "The Storefront" design from reference `Downloads/frontend`,
 * plus pricing tiers and live appraisal in `TryIt`.
 */

import { useEffect } from "react";
import { useLocation } from "react-router-dom";
import {
  Nav,
  Hero,
  Philosophy,
  Editorial,
  TryIt,
  Audience,
  Numbers,
  Developer,
  PricingSection,
  Closing,
  Footer,
} from "../components/landing";

export default function LandingPage() {
  const location = useLocation();

  useEffect(() => {
    const scrollTo = (location.state as { scrollTo?: string })?.scrollTo;
    if (!scrollTo) return;
    const el = document.getElementById(scrollTo);
    if (el) requestAnimationFrame(() => el.scrollIntoView({ behavior: "smooth", block: "start" }));
  }, [location.state, location.key]);

  return (
    <>
      <Nav />
      <Hero />
      <Philosophy />
      <Editorial />
      <TryIt />
      <Audience />
      <Numbers />
      <Developer />
      <PricingSection />
      <Closing />
      <Footer />
    </>
  );
}
