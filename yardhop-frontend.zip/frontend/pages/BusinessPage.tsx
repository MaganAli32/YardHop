import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import Navbar from '../components/Navbar';
import { ArrowRight } from 'lucide-react';
import { supabase } from '../lib/supabase';

const USE_CASES = [
  'Estate sale company',
  'Thrift store / resale chain',
  'Insurance / claims appraisal',
  'Retail buyback program',
  'Pawn shop',
  'Liquidation / auction house',
  'Other',
];

export default function BusinessPage() {
  const [formData, setFormData] = useState({ name: '', company: '', email: '', use_case: '' });
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  // Scroll reveal — identical to LandingPage
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) entry.target.classList.add('is-visible');
        });
      },
      { threshold: 0.15, rootMargin: '0px 0px -40px 0px' }
    );
    document.querySelectorAll('.scroll-reveal').forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, []);

  // Scroll to waitlist if hash present
  useEffect(() => {
    if (window.location.hash === '#waitlist') {
      setTimeout(() => {
        document.getElementById('waitlist')?.scrollIntoView({ behavior: 'smooth' });
      }, 100);
    }
  }, []);

  const handleSubmit = async () => {
    if (!formData.name || !formData.email || !formData.company) {
      setError('Please fill in all required fields.');
      return;
    }
    setLoading(true);
    setError('');
    try {
      const { error: sbError } = await supabase
        .from('business_waitlist')
        .insert([formData] as any);
      if (sbError) throw sbError;
      setSubmitted(true);
    } catch {
      setError('Something went wrong. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="business-page bg-[#F5F0E8] text-[#1A1A18] font-['Manrope'] antialiased overflow-x-hidden">
      <style>{`        .business-page { --forest: #2C4A3E; --terracotta: #C4622D; --mist: #E8E2D9; --parchment: #F5F0E8; --cream: #FAF7F2; --ink: #1A1A18; --muted: #5c665f; }
        .scroll-reveal { opacity: 0; transform: translateY(30px); transition: opacity 0.9s cubic-bezier(0.25, 1, 0.5, 1), transform 0.9s cubic-bezier(0.25, 1, 0.5, 1); }
        .scroll-reveal.is-visible { opacity: 1 !important; transform: translateY(0) !important; }
        .scroll-reveal.d1 { transition-delay: 0.1s; } .scroll-reveal.d2 { transition-delay: 0.2s; } .scroll-reveal.d3 { transition-delay: 0.3s; } .scroll-reveal.d4 { transition-delay: 0.4s; }
        @keyframes scrolld { 0% { top: -100%; } 50%, 100% { top: 100%; } }
        .scroll-line-inner { position: absolute; left: 0; width: 100%; height: 100%; background: var(--terracotta); top: -100%; animation: scrolld 2s ease-in-out infinite; }
        .feat-row:hover { padding-left: 12px; }
        .feat-row { transition: padding-left 0.3s ease; }
      `}</style>

      <Navbar />

      {/* ── 1. HERO ───────────────────────────────────────── */}
      <section className="min-h-screen flex flex-col justify-center items-center text-center relative pt-[120px] pb-[80px] md:pt-[140px] md:pb-[100px] px-6">
        <div className="scroll-reveal d1 inline-flex items-center gap-2 text-[13px] font-semibold text-[#9A9A9A] tracking-[0.5px] mb-10">
          <span className="w-1.5 h-1.5 rounded-full bg-[#C4622D]" style={{ animation: 'breathe 3s ease-in-out infinite' }} />
          API — Private Beta
        </div>

        <h1 className="scroll-reveal d1 font-serif text-[clamp(52px,7vw,96px)] font-normal text-[#1A1A18] tracking-[-2px] leading-[1.05] max-w-[860px]">
          Price your inventory.<br />
          <em className="italic text-[#C4622D]">Not just one item.</em>
        </h1>

        <p className="scroll-reveal d2 mt-7 text-[18px] leading-[1.6] text-[#6B6B6B] max-w-[460px]">
          One API call. A photo or description in, a market-accurate price range out — sourced from eBay, Mercari, Google Shopping, and Craigslist.
        </p>

        <div className="scroll-reveal d3 mt-12 flex flex-col sm:flex-row items-center justify-center gap-3 w-full sm:w-auto">
          <a
            href="#waitlist"
            onClick={(e) => { e.preventDefault(); document.getElementById('waitlist')?.scrollIntoView({ behavior: 'smooth' }); }}
            className="inline-flex items-center gap-2 py-3.5 px-8 rounded-sm text-[15px] font-semibold bg-[#2C4A3E] text-[#F5F0E8] hover:bg-[#3a5f50] hover:shadow-sm transition-all w-full sm:w-auto justify-center"
          >
            Join the API Waitlist
            <ArrowRight size={16} strokeWidth={2.5} />
          </a>
          <Link
            to="/#steps"
            className="inline-flex items-center gap-2 py-3.5 px-8 rounded-sm text-[15px] font-semibold bg-transparent text-[#2C4A3E] border border-[#2C4A3E] hover:bg-[#2C4A3E]/5 transition-all w-full sm:w-auto justify-center no-underline"
          >
            See consumer app
          </Link>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2">
          <div className="w-px h-8 bg-[#E8E2D9] relative overflow-hidden">
            <div className="scroll-line-inner" />
          </div>
        </div>
      </section>

      {/* ── 2. BUILT FOR BAR ──────────────────────────────── */}
      <div className="border-y border-mist py-7 px-6">
        <div className="max-w-[1200px] mx-auto">
          <p className="text-[11px] font-bold uppercase tracking-[2px] text-[#9A9A9A] text-center mb-5">
            Built for
          </p>
          <div className="flex flex-wrap justify-center gap-x-10 gap-y-3">
            {['Estate Sale Companies', 'Thrift Store Chains', 'Insurance Appraisers', 'Retail Buyback Programs', 'Pawn Shop Networks', 'Liquidation Houses'].map((label) => (
              <span key={label} className="text-[14px] font-medium text-[#9A9A9A]">{label}</span>
            ))}
          </div>
        </div>
      </div>

      {/* ── 3. USE CASES — dark section, divider row style ── */}
      <section className="bg-[#2C4A3E] text-white py-[100px] md:py-[160px] px-6 md:px-[56px]">
        <div className="max-w-[1200px] mx-auto">
          <div className="mb-16 md:mb-[100px]">
            <p className="scroll-reveal text-[12px] font-bold uppercase tracking-[2px] mb-5" style={{ color: 'rgba(196,98,45,0.85)' }}>
              Use Cases
            </p>
            <h2 className="scroll-reveal d1 font-serif text-[clamp(36px,4.5vw,56px)] font-normal text-white tracking-[-1px] max-w-[600px]">
              The secondhand economy runs on pricing decisions.
            </h2>
          </div>

          <div className="divide-y divide-white/[0.08]">
            {[
              {
                num: '01',
                title: 'Estate sale companies',
                desc: 'Your team photographs each item. YardFront returns a price range, confidence score, and comparable sold listings — instantly. Price 500 items in an afternoon, not a week.',
              },
              {
                num: '02',
                title: 'Thrift store chains',
                desc: "That Nike jacket in your donation bin could be worth $140 on Depop. YardFront flags high-value items at intake so your team prices them right the first time. Stop leaving money on the table.",
              },
              {
                num: '03',
                title: 'Insurance & claims',
                desc: 'Market-value estimates sourced from real sold transactions — not sticker prices. Every appraisal is timestamped, traceable, and exportable for claims documentation.',
              },
              {
                num: '04',
                title: 'Retail buyback programs',
                desc: 'REI, GameStop, Apple — any business buying back used goods needs defensible pricing. Integrate our API into your intake flow and price in real time.',
              },
            ].map((row, i) => (
              <div
                key={row.num}
                className={`scroll-reveal feat-row grid grid-cols-1 md:grid-cols-[200px_1fr] gap-4 md:gap-12 py-12 items-baseline border-t border-white/[0.08] ${i === 3 ? 'border-b border-white/[0.08]' : ''} ${['d1','d2','d3','d4'][i]}`}
              >
                <span className="font-serif text-[18px] text-[#C4622D]">{row.num}</span>
                <div>
                  <h3 className="text-[22px] font-semibold text-white tracking-[-0.3px] mb-2">{row.title}</h3>
                  <p className="text-[15px] leading-[1.7] text-white/40 max-w-[520px]">{row.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── 4. HOW IT WORKS — 3-step grid, match steps section */}
      <section className="py-[100px] md:py-[160px] px-6 md:px-[56px]">
        <div className="max-w-[1200px] mx-auto">
          <div className="text-center mb-16 md:mb-[100px]">
            <p className="scroll-reveal text-[12px] font-bold uppercase tracking-[2px] text-[#C4622D] mb-5">
              How It Works
            </p>
            <h2 className="scroll-reveal d1 font-serif text-[clamp(36px,4.5vw,56px)] font-normal text-[#1A1A18] tracking-[-1px]">
              One request. Five sources. Two seconds.
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-12 md:gap-8">
            {[
              { num: '01', title: 'Send a photo or description', desc: 'POST to /api/v1/appraise with an image URL, text description, or both.' },
              { num: '02', title: 'AI identifies the item', desc: 'Gemini Vision extracts item name, brand, model, and condition signals from the photo.' },
              { num: '03', title: 'Live market query', desc: 'We pull real-time sold listings from eBay, Mercari, Google Shopping, and Craigslist simultaneously.' },
              { num: '04', title: 'Price range returned', desc: 'Get low, high, and recommended price with a confidence score and full source breakdown.' },
            ].map((step, i) => (
              <div key={step.num} className={`scroll-reveal ${['d1','d2','d3','d4'][i]}`}>
                <div className="font-serif text-[64px] leading-none text-[#E8E2D9] mb-6">{step.num}</div>
                <h3 className="text-[18px] font-bold text-[#1A1A18] tracking-[-0.3px] mb-3">{step.title}</h3>
                <p className="text-[15px] leading-[1.7] text-[#6B6B6B]">{step.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── 5. API PREVIEW — match demo appraisal card style ─ */}
      <section className="px-6 pb-[100px] md:pb-[160px] flex justify-center">
        <div className="scroll-reveal w-full max-w-[720px] bg-[#FAF7F2] border border-[#E8E2D9] rounded-sm overflow-hidden shadow-sm">
          <div className="flex justify-between items-center py-5 px-6 md:py-5 md:px-7 border-b border-[#E8E2D9]">
            <div className="flex gap-1.5 items-center">
              <span className="w-2 h-2 rounded-full bg-[#FF5F57]" />
              <span className="w-2 h-2 rounded-full bg-[#FFBD2E]" />
              <span className="w-2 h-2 rounded-full bg-[#28C840]" />
              <span className="text-[13px] font-medium text-[#9A9A9A] ml-2.5">POST /api/v1/appraise</span>
            </div>
            <span className="text-[12px] font-semibold text-[#16A34A] bg-[rgba(22,163,74,0.08)] py-1 px-3 rounded-sm">
              200 OK
            </span>
          </div>
          <div className="py-8 px-6 md:px-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <p className="text-[11px] font-bold uppercase tracking-[2px] text-[#9A9A9A] mb-3">Request</p>
                <pre className="text-[13px] font-mono text-[#6B6B6B] leading-relaxed bg-[#FAF7F2] rounded-sm p-4 overflow-x-auto">{`{
  "image_url": "https://...",
  "condition": "good",
  "category": "electronics"
}`}</pre>
              </div>
              <div>
                <p className="text-[11px] font-bold uppercase tracking-[2px] text-[#9A9A9A] mb-3">Response</p>
                <pre className="text-[13px] font-mono text-[#6B6B6B] leading-relaxed bg-[#FAF7F2] rounded-sm p-4 overflow-x-auto">{`{
  "item_name": "Canon AE-1",
  "price_low": 65,
  "price_high": 110,
  "price_recommended": 85,
  "confidence": 8.2,
  "sources": [
    "ebay_sold",
    "mercari",
    "craigslist"
  ]
}`}</pre>
              </div>
            </div>
            <div className="mt-6 pt-6 border-t border-[#E8E2D9] flex flex-wrap gap-2">
              {['2s avg response', '5+ data sources', 'JSON + webhooks', '99.5% uptime'].map((label) => (
                <span key={label} className="text-[12px] font-medium text-[#6B6B6B] py-1.5 px-3 bg-[#FAF7F2] rounded-sm">
                  {label}
                </span>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ── 6. PRICING — match landing page pricing section ─── */}
      <section className="bg-[#FAF7F2] py-[100px] md:py-[160px] px-6 md:px-[56px]">
        <div className="max-w-[1200px] mx-auto">
          <div className="text-center mb-16">
            <p className="scroll-reveal text-[12px] font-bold uppercase tracking-[2px] text-[#C4622D] mb-5">
              Pricing
            </p>
            <h2 className="scroll-reveal d1 font-serif text-[clamp(36px,4.5vw,56px)] font-normal text-[#1A1A18] tracking-[-1px] mb-4">
              Pay for what you use.
            </h2>
            <p className="scroll-reveal d2 text-[18px] leading-[1.6] text-[#6B6B6B] max-w-[400px] mx-auto">
              API access is in private beta. Join the waitlist to lock in early pricing.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
            {[
              {
                name: 'Starter',
                price: '$99',
                limit: '500 appraisals/mo',
                features: ['REST API access', '5+ pricing sources', 'JSON responses', 'Email support', '99.5% uptime SLA'],
              },
              {
                name: 'Growth',
                price: '$299',
                limit: '2,000 appraisals/mo',
                features: ['Everything in Starter', 'Bulk CSV upload', 'Confidence breakdowns', 'Webhook delivery', 'Priority support'],
                popular: true,
              },
              {
                name: 'Scale',
                price: '$799',
                limit: '7,500 appraisals/mo',
                features: ['Everything in Growth', 'Category analytics', 'Custom thresholds', 'Dedicated Slack', '99.9% SLA'],
              },
            ].map((tier) => (
              <div
                key={tier.name}
                className={`scroll-reveal relative rounded-sm p-7 shadow-sm ${
                  tier.popular
                    ? 'bg-[#2C4A3E] text-white'
                    : 'bg-white border border-[#E8E2D9]'
                }`}
              >
                {tier.popular && (
                  <span className="absolute -top-3 left-6 bg-[#C4622D] text-[#FAF7F2] text-xs font-bold px-3 py-1 rounded-sm">
                    Most Popular
                  </span>
                )}
                <p className={`text-[13px] font-semibold mb-1 ${tier.popular ? 'text-white/50' : 'text-[#9A9A9A]'}`}>
                  {tier.name}
                </p>
                <div className="flex items-baseline gap-1 mb-1">
                  <span className={`text-[36px] font-bold tracking-[-1.5px] ${tier.popular ? 'text-white' : 'text-[#1A1A18]'}`}>
                    {tier.price}
                  </span>
                  <span className={`text-[14px] ${tier.popular ? 'text-white/30' : 'text-[#9A9A9A]'}`}>/mo</span>
                </div>
                <p className={`text-[13px] mb-6 ${tier.popular ? 'text-white/40' : 'text-[#9A9A9A]'}`}>
                  {tier.limit}
                </p>
                <ul className="space-y-2.5 mb-7">
                  {tier.features.map((f) => (
                    <li key={f} className={`flex items-start gap-2 text-[14px] ${tier.popular ? 'text-white/60' : 'text-[#6B6B6B]'}`}>
                      <span className="text-[#C4622D] mt-0.5 shrink-0">✓</span>
                      {f}
                    </li>
                  ))}
                </ul>
                <button
                  onClick={() => document.getElementById('waitlist')?.scrollIntoView({ behavior: 'smooth' })}
                  className={`w-full py-3 rounded-sm text-[14px] font-semibold transition-all ${
                    tier.popular
                      ? 'bg-[#F5F0E8] text-[#2C4A3E] hover:bg-[#FAF7F2] border border-[#F5F0E8]'
                      : 'border border-[#2C4A3E] text-[#2C4A3E] hover:bg-[#2C4A3E]/5'
                  }`}
                >
                  Join waitlist
                </button>
              </div>
            ))}
          </div>

          {/* Enterprise row */}
          <div className="scroll-reveal bg-white border border-[#E8E2D9] rounded-sm p-7 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 shadow-sm">
            <div>
              <p className="text-[16px] font-bold text-[#1A1A18] tracking-[-0.3px] mb-1">Enterprise</p>
              <p className="text-[14px] text-[#9A9A9A]">
                Unlimited appraisals · On-premise option · Custom integrations · Dedicated account manager
              </p>
            </div>
            <a
              href="mailto:hello@yardfront.com"
              className="shrink-0 inline-flex items-center gap-2 py-3 px-7 rounded-sm text-[14px] font-semibold border-[1.5px] border-[#E8E2D9] text-[#1A1A18] hover:border-[#9A9A9A] transition-all no-underline"
            >
              Contact us
            </a>
          </div>
        </div>
      </section>

      {/* ── 7. WAITLIST FORM ──────────────────────────────── */}
      <section id="waitlist" className="py-[100px] md:py-[160px] px-6 flex flex-col items-center text-center">
        <p className="scroll-reveal text-[12px] font-bold uppercase tracking-[2px] text-[#C4622D] mb-4">
          Early Access
        </p>
        <h2 className="scroll-reveal d1 font-serif text-[clamp(36px,4.5vw,56px)] font-normal text-[#1A1A18] tracking-[-1px] mb-4">
          Get <em className="italic text-[#C4622D]">early access.</em>
        </h2>
        <p className="scroll-reveal d2 text-[17px] text-[#6B6B6B] mb-14 max-w-[380px]">
          We're onboarding a small group of early API partners. Join the waitlist and we'll reach out directly.
        </p>

        <div className="scroll-reveal d3 w-full max-w-[480px]">
          {submitted ? (
            <div className="bg-[#FAF7F2] border border-[#E8E2D9] rounded-sm p-12 text-center">
              <div className="w-12 h-12 rounded-full bg-[rgba(196,98,45,0.1)] flex items-center justify-center mx-auto mb-4">
                <span className="text-[#C4622D] text-xl">✓</span>
              </div>
              <h3 className="font-serif text-[24px] text-[#1A1A18] tracking-[-0.5px] mb-2">
                You're on the list.
              </h3>
              <p className="text-[15px] text-[#6B6B6B]">
                We'll reach out with API access details as we onboard early partners.
              </p>
            </div>
          ) : (
            <div className="bg-[#FAF7F2] border border-[#E8E2D9] rounded-sm p-8 text-left shadow-sm">
              <div className="space-y-4">
                {[
                  { label: 'Your name', key: 'name', placeholder: 'Jane Smith', type: 'text' },
                  { label: 'Company', key: 'company', placeholder: 'Acme Estate Sales', type: 'text' },
                  { label: 'Work email', key: 'email', placeholder: 'jane@acmeestate.com', type: 'email' },
                ].map((field) => (
                  <div key={field.key}>
                    <label className="block text-[13px] font-semibold text-[#6B6B6B] mb-1.5">
                      {field.label}
                    </label>
                    <input
                      type={field.type}
                      value={formData[field.key as keyof typeof formData]}
                      onChange={(e) => setFormData({ ...formData, [field.key]: e.target.value })}
                      placeholder={field.placeholder}
                      className="w-full border border-[#E8E2D9] rounded-sm px-4 py-3 text-[15px] text-[#1A1A18] placeholder-[#C0C0C0] focus:outline-none focus:border-[#9A9A9A] transition-colors bg-white"
                    />
                  </div>
                ))}
                <div>
                  <label className="block text-[13px] font-semibold text-[#6B6B6B] mb-1.5">
                    Best describes your business
                  </label>
                  <select
                    value={formData.use_case}
                    onChange={(e) => setFormData({ ...formData, use_case: e.target.value })}
                    className="w-full border border-[#E8E2D9] rounded-sm px-4 py-3 text-[15px] text-[#1A1A18] focus:outline-none focus:border-[#9A9A9A] transition-colors bg-white appearance-none"
                  >
                    <option value="">Select one…</option>
                    {USE_CASES.map((uc) => (
                      <option key={uc} value={uc}>{uc}</option>
                    ))}
                  </select>
                </div>
              </div>

              {error && (
                <p className="text-red-500 text-[13px] mt-3">{error}</p>
              )}

              <button
                onClick={handleSubmit}
                disabled={loading}
                className="w-full mt-6 inline-flex items-center justify-center gap-2 py-3.5 px-8 rounded-sm text-[15px] font-semibold bg-[#2C4A3E] text-[#F5F0E8] hover:bg-[#3a5f50] hover:shadow-sm transition-all disabled:opacity-50"
              >
                {loading ? 'Submitting…' : (
                  <>
                    Request API Access
                    <ArrowRight size={16} strokeWidth={2.5} />
                  </>
                )}
              </button>
            </div>
          )}
        </div>
      </section>

      {/* ── 8. FINAL CTA — match landing page final section ── */}
      <section className="py-[120px] md:py-[200px] px-6 text-center">
        <h2 className="scroll-reveal font-serif text-[clamp(44px,6vw,80px)] font-normal text-[#1A1A18] tracking-[-2px] leading-[1.05] mb-10">
          Stop pricing by gut.<br />
          Start <em className="italic text-[#C4622D]">pricing by data.</em>
        </h2>
        <button
          onClick={() => document.getElementById('waitlist')?.scrollIntoView({ behavior: 'smooth' })}
          className="scroll-reveal d1 inline-flex items-center gap-2 bg-[#2C4A3E] text-[#F5F0E8] font-semibold text-[17px] py-4 px-10 rounded-sm hover:bg-[#3a5f50] transition-colors"
        >
          Join the Waitlist
          <ArrowRight size={18} strokeWidth={2.5} />
        </button>
      </section>

      {/* ── 9. FOOTER — exact match to landing page footer ─── */}
      <footer className="border-t border-[#E8E2D9] py-10 md:py-12 px-6 md:px-[56px] flex flex-col md:flex-row justify-between items-center gap-5 md:gap-0 text-center md:text-left">
        <div className="text-[13px] text-[#5c665f]">© 2026 YardFront · Berkeley, CA</div>
        <div className="flex gap-7">
          <Link to="/privacy-policy" className="text-[13px] text-[#5c665f] hover:text-[#2C4A3E] transition-colors no-underline">Privacy</Link>
          <Link to="/terms-of-service" className="text-[13px] text-[#5c665f] hover:text-[#2C4A3E] transition-colors no-underline">Terms</Link>
          <Link to="/" className="text-[13px] text-[#5c665f] hover:text-[#2C4A3E] transition-colors no-underline">Consumer App</Link>
        </div>
      </footer>
    </div>
  );
}
